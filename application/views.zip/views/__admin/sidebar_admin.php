<!-- Sidebar -->
<ul class="sidebar navbar-nav">
	<li class="nav-item">
		<a class="nav-link" href="<?= base_url('admin/dashboard') ?>">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>Dashboard</span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= base_url('admin/guru') ?>">
		<i class="fas fa-user-graduate"></i>
			<span>Data Guru</span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= base_url('admin/murid') ?>">
		<i class="fas fa-user-graduate"></i>
			<span>Data Murid</span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= base_url('admin/murid/tambahMurid') ?>">
		<i class="fas fa-user-plus"></i>
			<span>Tambah Data Murid</span>
		</a>
	</li>
</ul>
